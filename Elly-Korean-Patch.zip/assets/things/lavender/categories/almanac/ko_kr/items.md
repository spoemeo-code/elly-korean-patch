```json
{
    "icon": "things:bater_wucket",
    "title": "아이템"
}
```

일반 아이템을 모두 모아둔 곳입니다
