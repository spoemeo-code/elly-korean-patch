```json
{
    "icon": "things:moss_necklace",
    "title": "장신구"
}
```

장신구를 모두 모아둔 곳입니다
