```json
{
  "icon": "things:bater_wucket",
  "title": "무한 물 양동이",
  "category": "things:items",
  "associated_items": [
    "things:bater_wucket"
  ]
}
```

전설에 따르면 옛날 옛적 레딧이라는 세계가 있었는데, 그곳 주민들은 세상 누구보다 괴상했다고 합니다.
어느 날 그곳에서 물 양동이를 뒤집어놓은 물건, 이른바 {light_purple}무한 물 양동이{}라는 발상이
튀어나왔고, 그걸 본 사람은 모두 공포에 떨었다고 합니다.

;;;;;

<recipe;things:bater_wucket>

이 저주받은 물건은 순수한 물을 대체 뭔지 모를 힘으로 붙잡아 만든 것으로, 세상에서 가장 순수한 이
물질을 사실상 끝없이 쏟아낸다고 합니다.

*{#999999}.. 뭐라고?{}*
