```json
{
  "icon": "things:infernal_scepter",
  "title": "지옥 홀",
  "category": "things:items",
  "associated_items": [
    "things:infernal_scepter"
  ]
}
```

{light_purple}네더라이트 주괴{} 몇 개로 보강한 {light_purple}블레이즈 막대{}에 {light_purple}용암 양동이{}를
척 붙인다니, 기막힌 생각 같지 않나요? 실제로 훌륭한 무기가 됩니다. {light_purple}지옥 홀{}은
{light_purple}화염구{}를 달궈 날려 보내고, 그렇게 날아간 화염구는 꽤 치명적입니다.
다만 이 과정이 워낙 격해서,

;;;;;

<recipe;things:infernal_scepter>

아무리 튼튼한 네더라이트라도 영원히 버티지는 못합니다.
