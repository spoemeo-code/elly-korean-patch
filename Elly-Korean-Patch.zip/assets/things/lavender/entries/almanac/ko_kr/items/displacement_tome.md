```json
{
  "icon": "things:displacement_tome",
  "title": "차원이동서",
  "category": "things:items",
  "associated_items": [
    "things:displacement_tome",
    "things:displacement_page"
  ]
}
```

{light_purple}발광 먹물{}의 독특한 성질을 이용하면, {light_purple}엔더 진주{}가
{light_purple}차원이동 페이지{}에 적어둔 곳으로 데려다주게 만들 수 있습니다. 다만 페이지가 너무 약해서
따로는 못 쓰고, {light_purple}차원이동서{}에 끼워서 써야 합니다. 페이지에 장소를 적는 것도 이 책으로 합니다.

;;;;;

{light_purple}차원이동 페이지{}를 한 장 이상 가진 채 책을 열고 {gold}+{} 아이콘을 누르면 새 항목이 생기면서
페이지가 들어갑니다. 페이지를 {gold}우클릭{}하면 내용을 고치거나 버릴 수 있습니다. 책에는
{light_purple}엔더 진주{}도 따로 채워둘 수 있습니다. 아무 인벤토리에서나 책을 집어
{light_purple}엔더 진주{}에 대고 {gold}우클릭{}하면 됩니다.

;;;;;

<recipe;things:displacement_tome>

;;;;;

<recipe;things:displacement_page>
