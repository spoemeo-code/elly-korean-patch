```json
{
  "icon": "minecraft:apple",
  "title": "사과",
  "category": "things:items",
  "associated_items":[
    "minecraft:apple"
  ]
}
```

사과는 플레이어가 먹을 수 있는 음식입니다.


핫바에서 사과를 고른 채 사용 키를 꾹 누르거나, 얼굴에 끼우면 먹을 수 있습니다. 하나 먹으면 허기 4와 포화도 2.4가 찹니다.


퇴비통에 넣으면 65% (13⁄20) 확률로 퇴비가 한 단계 올라갑니다.

;;;;;

![](things:textures/gui/apple_patchouli.png,fit)

{#ff0000}사과{} 올바르게 끼우는 법
