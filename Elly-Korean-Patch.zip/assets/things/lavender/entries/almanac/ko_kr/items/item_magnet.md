```json
{
  "icon": "things:item_magnet",
  "title": "아이템 자석",
  "category": "things:items",
  "associated_items": [
    "things:item_magnet"
  ]
}
```

{light_purple}아이템 자석{}은 널린 물건을 치우거나, 뭐, 슬쩍하는 데 더없이 요긴합니다.
{gold}우클릭{}하면 광선을 쏘고, 안에 든 엔더 진주의 힘으로 주변 아이템을 전부 내 쪽으로 순간이동시킵니다.

;;;;;

<recipe;things:item_magnet>

쓸 때는 조금 조심하세요. 충전량을 너무 많이 써버리면 한동안 끌어오는 범위도, 충전 속도도 크게 떨어집니다.
