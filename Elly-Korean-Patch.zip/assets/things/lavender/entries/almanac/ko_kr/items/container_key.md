```json
{
  "icon": "things:container_key",
  "title": "보관함 열쇠",
  "category": "things:items",
  "associated_items": [
    "things:container_key"
  ]
}
```

살림살이를 지키고 싶다면 {light_purple}보관함 열쇠{}가 꽤 쓸모 있습니다. 상자나 화로 같은 보관함에 대고
{gold}웅크린 채 우클릭{}하면 잠기고, 다시 풀기 전까지는 {gold}그 열쇠 하나로만{} 열립니다.
잠금을 풀 때도 열쇠를 들고 똑같이 {gold}웅크린 채 우클릭{}하면 됩니다.

;;;;;

<recipe;things:container_key>

다만 작정한 사람이라면 보관함을 그냥 부숴버리면 그만이라는 건 알아두세요.
