```json
{
  "icon": "things:hardening_catalyst",
  "title": "경화 촉매",
  "category": "things:items",
  "associated_items": [
    "things:hardening_catalyst"
  ]
}
```

{light_purple}네더의 별{}을 온갖 단단한 것들과 섞었더니, 어째선지 액체가 나왔습니다. 그런데 이 액체가
재미있습니다. {gold}모루{}에서 내구도가 있는 물건에 부으면, 경험치를 조금 내는 대신 그 물건이
{gold}부서지지 않게{} 됩니다.

;;;;;

<recipe;things:hardening_catalyst>
