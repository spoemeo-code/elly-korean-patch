```json
{
  "icon": "things:recall_potion",
  "title": "회수의 물약",
  "category": "things:items",
  "associated_items": [
    "things:recall_potion"
  ]
}
```

마인크래프트만큼 오래된 발상일지도 모르는 {light_purple}회수의 물약{}은, 아직 아무도 원리를 모르는
아공간의 장난을 이용해 마시자마자 {gold}스폰 지점{}으로 돌려보내줍니다. 이 마법의 물약은
{gold}양조기{}에서 {light_purple}어색한 물약{}에 {light_purple}엔더 진주{}의 힘을 불어넣어 만듭니다.
