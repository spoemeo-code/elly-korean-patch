```json
{
  "icon": "things:gleaming_ore",
  "title": "빛나는 광석",
  "associated_items": [
    "things:gleaming_ore",
    "things:deepslate_gleaming_ore"
  ]
}
```

이 모드의 물건을 만들려면 거의 언제나 {light_purple}빛나는 광석{}이 필요합니다. 돌과 심층암이 맞닿는
땅속 깊은 곳에 있고, {light_purple}다이아몬드 곡괭이{} 이상으로 캐야
[빛나는 가루](^things:items/gleaming_materials)가 나옵니다. 광석이 귀할 때는 곡괭이에 {gold}행운{}을
걸어두면 좋지만, 늘어나는 양은 생각보다 적습니다.

;;;;;

![](things:textures/gui/gleaming_ore_patchouli.png,fit)

자연 속의 {light_purple}빛나는 광석{}. *{#999999}빛이 납니다{}*
