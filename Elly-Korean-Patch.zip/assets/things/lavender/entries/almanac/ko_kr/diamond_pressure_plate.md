```json
{
  "icon": "things:diamond_pressure_plate",
  "title": "다이아몬드 감압판",
  "associated_items": [
    "things:diamond_pressure_plate"
  ]
}
```

{light_purple}다이아몬드{}로 만든 감압판이라니 흔한 물건은 아니지만, 쓸모는 확실합니다.
이렇게 만든 감압판은 {gold}플레이어만 밟아야 작동{}해서, 드디어 현관 앞에 깔아둘 만한 감압판이 생겼습니다.

;;;;;

<recipe;things:diamond_pressure_plate>
