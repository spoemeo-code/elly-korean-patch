```json
{
    "title": "잡동사니 도감"
}
```

말 그대로 온갖 {gold}물건{}을 다루는 모드입니다.


시작하려면 먼저 동굴로 내려가 [빛나는 가루](^things:gleaming_ore)부터 캐오세요. 웬만한
물건은 다 이걸로 만듭니다.


문제가 생기거나 버그를 발견했다면 [Wisp Forest 디스코드](https://discord.com/invite/xrwHKktV2d)에 들르거나 [GitHub](https://github.com/wisp-forest/things/issues)에 제보해주세요.
