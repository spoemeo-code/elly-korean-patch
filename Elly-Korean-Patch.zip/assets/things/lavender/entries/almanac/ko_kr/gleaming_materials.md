```json
{
  "icon": "things:gleaming_powder",
  "title": "빛나는 재료",
  "associated_items": [
    "things:gleaming_powder",
    "things:gleaming_compound"
  ]
}
```

[빛나는 광석](^things:gleaming_ore)에서 나오는 {light_purple}빛나는 가루{}에는 꽤 쓸 만한 마법의 힘이
깃들어 있습니다. 좀 이상한 사람들은 이걸 원시 생명체로 치기도 할 정도입니다. 가루만으로는 쓸 데가
없지만, 온갖 도구와 장신구의 밑재료가 됩니다.

;;;;;

<recipe;things:gleaming_compound>

{light_purple}다이아몬드{}에 이 가루를 입혀볼 수도 있습니다. 그러면 훨씬 강한
{light_purple}빛나는 혼합물{}이 됩니다.
