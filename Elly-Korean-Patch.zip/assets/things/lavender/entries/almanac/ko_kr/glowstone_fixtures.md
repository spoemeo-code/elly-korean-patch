```json
{
  "icon": "things:quartz_glowstone_fixture",
  "title": "발광석 조명",
  "associated_items": [
    "things:quartz_glowstone_fixture",
    "things:stone_glowstone_fixture",
    "things:deepslate_glowstone_fixture"
  ]
}
```

작은 받침에 발광석 한 조각을 얹은 조명입니다. 발광석만큼 밝고, 예쁜 입자도 날립니다.


꽤 괜찮죠?

<recipe;things:quartz_glowstone_fixture>


;;;;;

<recipe;things:stone_glowstone_fixture>
<recipe;things:deepslate_glowstone_fixture>
