```json
{
  "icon": "things:placebo",
  "title": "플라시보",
  "category": "things:trinkets",
  "associated_items": [
    "things:placebo"
  ]
}
```

물약을 잔뜩 만드는 게 그리 힘든 일은 아니지만, 조금이라도 아낄 수 있으면 좋겠죠.
{light_purple}플라시보{}가 딱 그만큼 도와줍니다. 가끔 마시던 물약을 몰래 가짜 약으로 바꿔치기하는데,
어째선지 효과는 그대로 남습니다.

;;;;;

<recipe;things:placebo>

어떻게 그러는지는 아직 아무도 모릅니다. "그냥 됩니다"
