```json
{
  "icon": "things:hades_crystal",
  "title": "하데스의 수정",
  "category": "things:trinkets",
  "associated_items": [
    "things:hades_crystal"
  ]
}
```

네더의 더러운 열기를 {light_purple}빛나는 혼합물{}에 그대로 쬐면 {light_purple}하데스의 수정{}이 됩니다.
이렇게 바뀐 혼합물은 열을 빨아들여 없애는 법을 깨우쳐서, 착용자를 온갖 불로부터 힘닿는 데까지
지켜줍니다.

;;;;;

<recipe;things:hades_crystal>
