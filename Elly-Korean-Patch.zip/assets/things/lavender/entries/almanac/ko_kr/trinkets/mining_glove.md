```json
{
  "icon": "things:mining_gloves",
  "title": "채굴 장갑",
  "category": "things:trinkets",
  "associated_items": [
    "things:mining_gloves"
  ]
}
```

채굴은 마인크래프트의 핵심이지만, 한꺼번에 많이 캐려면 꽤 고됩니다.
{light_purple}채굴 장갑{}을 끼면 이게 한결 빨라집니다. 손이 더 튼튼하고 재빨라져서
채굴 속도가 크게 오릅니다.

;;;;;

<recipe;things:mining_gloves>
