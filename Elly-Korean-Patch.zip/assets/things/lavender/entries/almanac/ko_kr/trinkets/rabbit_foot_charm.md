```json
{
  "icon": "things:rabbit_foot_charm",
  "title": "토끼 발 부적",
  "category": "things:trinkets",
  "associated_items": [
    "things:rabbit_foot_charm"
  ]
}
```

흔한 토끼 발 부적은 행운을 불러온다지만, {light_purple}빛나는 가루{}를 뿌리면 얘기가 달라집니다.
물약 재료로 쓰일 때의 힘이 깨어난 {light_purple}토끼 발{}이 착용자에게 영구적인
{gold}점프 강화 II{}를 줍니다.

;;;;;

<recipe;things:rabbit_foot_charm>
