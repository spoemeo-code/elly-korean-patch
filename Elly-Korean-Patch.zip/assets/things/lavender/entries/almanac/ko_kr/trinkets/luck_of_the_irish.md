```json
{
  "icon": "things:luck_of_the_irish",
  "title": "아일랜드인의 행운",
  "category": "things:trinkets",
  "associated_items": [
    "things:luck_of_the_irish"
  ]
}
```

보통 {light_purple}독이 있는 감자{}는 그냥 꽝입니다. 하지만 {light_purple}아일랜드인의 행운{}을 만들어
차고 있으면 여기서 쏠쏠한 이득을 볼 수 있습니다. 안에 든 {light_purple}빛나는 혼합물{}이 원래 걸려야 할
독을 {gold}재생 II{}로 바꿔주는데,

;;;;;

<recipe;things:luck_of_the_irish>

같이 넣은 {light_purple}마법이 부여된 황금 사과{}에게서 배운 덕분입니다.
