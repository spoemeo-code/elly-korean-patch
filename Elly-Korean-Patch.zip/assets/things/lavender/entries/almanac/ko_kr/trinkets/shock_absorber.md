```json
{
  "icon": "things:shock_absorber",
  "title": "충격 흡수기",
  "category": "things:trinkets",
  "associated_items": [
    "things:shock_absorber"
  ]
}
```

최고 속도로 벽에 머리를 박거나 땅에 발을 찧는 고통은 다들 압니다. 마침 {light_purple}충격 흡수기{}가
그 충격을 덜어줍니다. {light_purple}팬텀 막{}과 {light_purple}양털{}로 만들고
[빛나는 혼합물](^things:items/gleaming_materials)로 이어붙인 멋진 신발로, {gold}낙하 피해와 운동 피해를
75% 줄여줍니다{}.

;;;;;

<recipe;things:shock_absorber>
