```json
{
  "icon": "things:arm_extender",
  "title": "팔 연장기",
  "category": "things:trinkets",
  "associated_items": [
    "things:arm_extender"
  ]
}
```

마인크래프트에서 제일 많이 하는 일이 적과 바위를 주먹으로 패는 거니까, {gold}손이 더 멀리 닿으면{}
하루하루가 한결 편해질 겁니다. 그러라고 만든 듯한 물건이 바로 {light_purple}팔 연장기{}입니다.
팔 끝에 *엄청 무거운 피스톤*을 묶어놓은 거나 다름없고, {gold}닿는 거리가 2블록 늘어납니다{}.

;;;;;

<recipe;things:arm_extender>
