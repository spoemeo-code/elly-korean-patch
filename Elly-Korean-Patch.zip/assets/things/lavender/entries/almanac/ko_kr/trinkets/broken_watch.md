```json
{
  "icon": "things:broken_watch",
  "title": "고장난 시계",
  "category": "things:trinkets",
  "associated_items": [
    "things:broken_watch"
  ]
}
```

{light_purple}고장난 시계{}가 뭐에 쓰이겠냐 싶겠지만, [빛나는 혼합물](^things:items/gleaming_materials)로
고장난 시계를 붙잡아두면 걸려 있는 {gold}상태 효과{}가 좋아집니다. {gold}지속시간이 50% 늘어나거든요{}.
{light_purple}시계{}를 부수려면 엄청난 힘이 필요해서 {gold}제작대{}로는 못 만듭니다.

;;;;;

대신 {light_purple}가죽{}과 {light_purple}시계{}, {gold}빛나는 혼합물{} 하나를 바닥에 던져놓고...

![](things:textures/gui/watch_patchouli.png,fit)

;;;;;

...{gold}피스톤으로 짓누르세요{}.
