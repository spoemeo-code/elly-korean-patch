```json
{
  "icon": "things:riot_gauntlet",
  "title": "폭동 건틀렛",
  "category": "things:trinkets",
  "associated_items": [
    "things:riot_gauntlet"
  ]
}
```

{light_purple}빛나는 혼합물{}의 마법에 {light_purple}네더라이트 주괴{} 두 개로 면상을 갈기는 순수한 물리력을
더한 {light_purple}폭동 건틀렛{}은 착용자의 힘을 크게 끌어올립니다. 무기 없이도 좀비 한 마리쯤은 가볍게
해체할 수 있으니, 전사에게 이만한 친구가 없습니다.

;;;;;

<recipe;things:riot_gauntlet>
