```json
{
  "icon": "things:ender_pouch",
  "title": "엔더 주머니",
  "category": "things:trinkets",
  "associated_items": [
    "things:ender_pouch"
  ]
}
```

탐험하다 가방이 꽉 차서 일찍 돌아와야 하는 서러움은 다들 압니다. 이런 흔한 재료로 그 문제를 아예
없앨 수는 없지만, {light_purple}엔더 주머니{}가 있으면 모험하는 시간을 거의 두 배로 늘릴 수 있습니다.
들고 다니는 엔더 상자나 마찬가지라서, 언제든 {gold}엔더 상자{}를 바로 열 수 있습니다.

;;;;;

<recipe;things:ender_pouch>
