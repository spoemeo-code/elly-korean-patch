```json
{
  "icon": "things:socks",
  "title": "양말",
  "category": "things:trinkets",
  "associated_items": [
    "things:socks"
  ]
}
```

잘나가는 애들은 다 양말을 신는다는 건 모두가 아는 사실입니다. 그러니 당연히 한 켤레 장만할 수 있습니다.
[빛나는 가루](^things:items/gleaming_materials)로 꾸민 {light_purple}양털{}로 쉽게 만들 수 있고, 신자마자
{gold}발이 빨라집니다{}. 더 빨라지고 싶다면 제작대에서 {light_purple}양말{}에 {gold}신속의 물약 II{}와
[빛나는 가루](^things:items/gleaming_materials)를 더해 강화할 수 있습니다.

;;;;;

<recipe;things:socks>

비슷하게 {light_purple}빛나는 혼합물{} 하나를 써서 {light_purple}토끼 발 부적{}을 합칠 수도 있습니다.
그러면 {gold}점프 강화 II{}와 {gold}계단 자동 오르기{}가 붙습니다. {light_purple}점프 강화{}는
<keybind;key.things.toggle_socks_jump_boost> 키로 켜고 끌 수 있습니다.
