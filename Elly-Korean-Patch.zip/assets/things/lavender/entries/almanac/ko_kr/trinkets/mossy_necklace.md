```json
{
  "icon": "things:moss_necklace",
  "title": "이끼 낀 목걸이",
  "category": "things:trinkets",
  "associated_items": [
    "things:moss_necklace"
  ]
}
```

상처 치료는 영 내키지 않는 일인데, 다행히 {light_purple}이끼 낀 목걸이{}가 기꺼이 대신 해줍니다.
햇빛이든 조명이든 빛만 있으면 알아서 상처를 낫게 합니다. 그 방식이 썩 깔끔하지는 않습니다.
이끼는 자라고, 상처는 메워진다는 정도로만 말해두죠.

;;;;;

<recipe;things:moss_necklace>

*{#999999}"천연" 반창고{}*
