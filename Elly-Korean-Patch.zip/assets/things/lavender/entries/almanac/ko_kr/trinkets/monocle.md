```json
{
  "icon": "things:monocle",
  "title": "단안경",
  "category": "things:trinkets",
  "associated_items": [
    "things:monocle"
  ]
}
```

단안경은 오래전부터 더 잘 보려고 쓰던 물건입니다. 렌즈에 {light_purple}빛나는 가루{}를 살짝 뿌리면
마법의 빛이 돌아서, 쓰고 있는 동안 {gold}야간 투시{}까지 덤으로 얻습니다.

;;;;;

<recipe;things:monocle>
