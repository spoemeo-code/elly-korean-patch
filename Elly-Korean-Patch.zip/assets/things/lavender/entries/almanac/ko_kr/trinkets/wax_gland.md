```json
{
  "icon": "things:enchanted_wax_gland",
  "title": "마법이 깃든 밀랍샘",
  "category": "things:trinkets",
  "associated_items": [
    "things:enchanted_wax_gland"
  ]
}
```

발에 {light_purple}밀랍샘{}을 묶는 건 사실 꽤 좋은 생각입니다. 자연에서 그렇듯, 하체에 밀랍을 바르면
물에 뜹니다. 게다가 이 밀랍샘에는 {light_purple}빛나는 혼합물{}이 섞여 있어서 물속에서 엄청나게
빨라지고, 덕분에 아주 쓸 만한 이동 수단이 됩니다.

;;;;;

<recipe;things:enchanted_wax_gland>

이 힘에도 약점이 있으니, 바로 열입니다. 하지만 [하데스의 수정](^things:trinkets/hades_crystal)을 함께
차면 해결됩니다.
