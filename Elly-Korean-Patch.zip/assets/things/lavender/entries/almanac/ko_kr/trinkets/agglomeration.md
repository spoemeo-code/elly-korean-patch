```json
{
  "icon": "things:agglomeration",
  "title": "결합체",
  "category": "things:trinkets",
  "associated_items": [
    "things:empty_agglomeration",
    "things:agglomeration"
  ]
}
```

장신구를 하나둘 모으다 보면 꼭 부딪히는 골칫거리가 있습니다. 같은 칸을 쓰는 장신구끼리는 하나만
골라야 한다는 거죠. 한 칸에 두 개를 낄 수 있다면 *정말* 좋지 않을까요? 다행히
{light_purple}결합체{}가 바로 그 일을 해줍니다.

먼저 만들어야 할 것은

;;;;;

<recipe;things:empty_agglomeration>

위에 보이는 {light_purple}빈 결합체{}입니다. 여기에 원하는 장신구 두 개를 합치면 되는데,
당연히 두 장신구는 {gold}적어도 한 칸은 겹쳐야{} 합니다.

어떤 장신구를 합칠지는

;;;;;

신중하게 고르세요. 지금까지 해본 바로는, 한번 합친 장신구는 다시 떼어낼 수 없었습니다.
