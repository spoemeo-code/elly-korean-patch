```json
{
  "icon": "things:bempty_ucket",
  "title": "무한 빈 양동이",
  "category": "things:items",
  "associated_items": [
    "things:bempty_ucket"
  ]
}
```

비교적 최근에 나온 발명품이지만, 걱정스럽기는 마찬가지입니다. {light_purple}무한 빈 양동이{}는
[무한 물 양동이](^things:items/bater_wucket)에서 갈라져 나온 물건입니다.

<recipe;things:bempty_ucket>

;;;;;

놀랍게도(네, 사실 다들 예상했죠) 이 양동이는 어떤 액체든 {gold}끝없이 퍼담아 없애버립니다{}.
여러모로 편하긴 하지만 조심해서 써야 합니다. 한번 {light_purple}무한 빈 양동이{}에 들어간 액체는
{gold}다시 꺼낼 방법이 없습니다{}.


*{#999999}... 점점 어이가 없어지네{}*
