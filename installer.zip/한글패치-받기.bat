﻿@echo off
chcp 65001 > nul
title 엘리 한글패치 받기
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0한글패치-받기.ps1"
